SAFE END DAY v21 REAL FIX

Root cause fixed:
- End Day report controls are now part of the real webpage, not an exported HTML string.
- Inventory/Sales startup crash removed.
- Safe End Day behavior retained.
