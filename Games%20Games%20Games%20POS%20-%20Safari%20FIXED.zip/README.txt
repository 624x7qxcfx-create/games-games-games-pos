Games! Games! Games! POS — Safari FIXED

This build fixes the JavaScript syntax error that prevented all buttons and barcode actions from working.

For the most reliable iPhone use:
1. Host index.html as a normal web page.
2. Open the hosted URL in Safari.
3. Do not open the HTML directly from the iPhone Files app if you need reliable storage/printing/export behavior.
